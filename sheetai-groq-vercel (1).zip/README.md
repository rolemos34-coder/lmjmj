# SheetAI - AI Spreadsheet Generator

Gere, edite, analise e exporte planilhas com **Groq** (Llama 3.3 70B).

## Rodar localmente

```bash
npm install
# chave em .env: GROQ_API_KEY=gsk-...
npm run dev
# http://localhost:3000
```

## Deploy na Vercel

```bash
npm i -g vercel
vercel login
vercel env add GROQ_API_KEY   # cole a chave gsk-...
vercel --prod
```

No dashboard: Environment Variable `GROQ_API_KEY` = sua chave Groq.

## Modelo

Padrão: `llama-3.3-70b-versatile`  
Override: `GROQ_MODEL=llama-3.1-8b-instant` (mais rápido/barato)
