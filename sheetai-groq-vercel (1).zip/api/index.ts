import type { VercelRequest, VercelResponse } from '@vercel/node';
import app from '../server';

/**
 * Vercel serverless entry — mounts the Express app.
 * All /api/* requests are routed here via vercel.json rewrites.
 */
export default function handler(req: VercelRequest, res: VercelResponse) {
  return app(req as any, res as any);
}
