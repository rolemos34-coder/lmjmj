import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

try {
  dotenv.config();
} catch (_) {}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));

const GROQ_MODEL = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';

function getGroqApiKey(): string {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    throw new Error('GROQ_API_KEY environment variable is missing.');
  }
  return apiKey;
}

/** Call Groq Chat Completions (OpenAI-compatible) and return text content. */
async function callGroq(
  system: string,
  user: string,
  opts: { temperature?: number; json?: boolean } = {}
): Promise<string> {
  const apiKey = getGroqApiKey();
  const body: Record<string, unknown> = {
    model: GROQ_MODEL,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
    temperature: opts.temperature ?? 0.2,
  };
  if (opts.json !== false) {
    body.response_format = { type: 'json_object' };
  }

  const resp = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`Groq API ${resp.status}: ${errText}`);
  }

  const data = (await resp.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const content = data.choices?.[0]?.message?.content || '';
  return content.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim();
}

function parseJsonSafe(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    // try extract first {...}
    const m = text.match(/\{[\s\S]*\}/);
    if (m) return JSON.parse(m[0]);
    throw new Error('Model did not return valid JSON');
  }
}

// 1. Generate Spreadsheet
app.post('/api/generate-spreadsheet', async (req: Request, res: Response) => {
  try {
    const { prompt, language = 'Portuguese', category } = req.body;

    if (!prompt || typeof prompt !== 'string') {
      res.status(400).json({ error: 'Prompt is required.' });
      return;
    }

    const system = `You are SheetAI, an expert financial analyst, spreadsheet architect, and data engineer.
Your task is to construct a complete, professional, production-ready spreadsheet based on the user's prompt.

You MUST respond strictly with valid JSON. Do NOT include markdown code fences or extra conversational text.

Target Language for headers, names, notes, summaries, and text: ${language}
Note: If language is Portuguese or Portuguese (BR), write all labels, titles, descriptions, recommendations, and metrics in natural Português do Brasil, using "R$" as default currency symbol for financial values.

JSON Schema:
{
  "title": "Spreadsheet Title",
  "description": "Brief description of this spreadsheet",
  "sheets": [
    {
      "id": "sheet-1",
      "name": "Sheet Name",
      "rowCount": 25,
      "colCount": 12,
      "cells": {
        "A1": {
          "value": "Header Name",
          "rawInput": "Header Name",
          "style": { "bold": true, "textColor": "#0f172a", "backgroundColor": "#f1f5f9", "textAlign": "left", "format": "text" }
        },
        "B2": {
          "value": 50000,
          "rawInput": "50000",
          "style": { "format": "currency", "currencySymbol": "R$", "textAlign": "right" }
        },
        "B10": {
          "value": 150000,
          "rawInput": "=SUM(B2:B9)",
          "style": { "bold": true, "format": "currency", "currencySymbol": "R$", "textAlign": "right", "backgroundColor": "#e2e8f0" }
        }
      },
      "charts": [
        {
          "id": "chart-1",
          "type": "bar",
          "title": "Receitas vs Despesas",
          "dataRange": { "startCell": "A1", "endCell": "C10" },
          "xAxisColumn": "A",
          "dataColumns": ["B", "C"]
        }
      ]
    }
  ],
  "insights": {
    "summary": "Resumo executivo",
    "keyMetrics": [{ "label": "Receita Total", "value": "R$ 150.000", "trend": "up" }],
    "recommendations": ["Recomendação estratégica"],
    "formulasUsed": [{ "formula": "=SUM(B2:B9)", "purpose": "Soma" }]
  }
}

Guidelines:
1. Populate realistic numbers, dates, categories, and headers.
2. Generate at least 8 to 15 rows of rich data.
3. Use Excel formulas: =SUM(), =AVERAGE(), =MIN(), =MAX(), =COUNT(), =IF(), etc. Set rawInput starting with "=" for formulas.
4. Style headers bold with light backgrounds; right-align numbers/currencies.
5. Include at least 1 chart (bar, line, pie, or area).
6. Valid cell keys like A1, B2, C3.`;

    const user = `User Request: "${prompt}"\n${category ? `Category: ${category}` : ''}`;
    const text = await callGroq(system, user, { temperature: 0.2 });
    const data = parseJsonSafe(text);
    res.json({ success: true, workbook: data });
  } catch (error: any) {
    console.error('Error in /api/generate-spreadsheet:', error);
    res.status(500).json({ error: error.message || 'Failed to generate spreadsheet.' });
  }
});

// 2. Edit Spreadsheet
app.post('/api/edit-spreadsheet', async (req: Request, res: Response) => {
  try {
    const { sheet, command, language = 'Portuguese' } = req.body;

    if (!sheet || !command) {
      res.status(400).json({ error: 'Sheet and command are required.' });
      return;
    }

    const system = `You are an AI Spreadsheet Editor.
Given a current sheet data object (cells, rows, columns), apply the user's modification command accurately.

User command: "${command}"
Language preference: ${language}

Return strictly a JSON object representing the updated sheet with "cells", "rowCount", "colCount", and optional "charts" and "message".
Do not include markdown fences.

Example:
{
  "cells": {},
  "rowCount": 30,
  "colCount": 12,
  "message": "Added 2026 forecast column with 12% growth rate formula."
}`;

    const user = `Current Sheet Data:\n${JSON.stringify(sheet, null, 2)}`;
    const text = await callGroq(system, user, { temperature: 0.1 });
    const updatedData = parseJsonSafe(text);
    res.json({ success: true, updatedSheet: updatedData });
  } catch (error: any) {
    console.error('Error in /api/edit-spreadsheet:', error);
    res.status(500).json({ error: error.message || 'Failed to edit spreadsheet.' });
  }
});

// 3. Formula Assistant
app.post('/api/ai-formula-assistant', async (req: Request, res: Response) => {
  try {
    const { prompt, targetCell = 'A1', context = '' } = req.body;

    if (!prompt) {
      res.status(400).json({ error: 'Prompt is required.' });
      return;
    }

    const system = `You are an expert Excel/Google Sheets formula generator.
The user wants a formula for cell ${targetCell} based on their request.
Context about the sheet layout: ${context}

Respond ONLY in JSON:
{
  "formula": "=SUM(B2:B12)",
  "explanation": "Summation of values from B2 through B12",
  "suggestedFormat": "currency"
}
suggestedFormat must be one of: currency, percentage, number, text`;

    const text = await callGroq(system, `Formula Request: "${prompt}"`, { temperature: 0.1 });
    const result = parseJsonSafe(text) as object;
    res.json({ success: true, ...result });
  } catch (error: any) {
    console.error('Error in /api/ai-formula-assistant:', error);
    res.status(500).json({ error: error.message || 'Failed to generate formula.' });
  }
});

// 4. Analyze Spreadsheet
app.post('/api/analyze-spreadsheet', async (req: Request, res: Response) => {
  try {
    const { sheet } = req.body;

    if (!sheet) {
      res.status(400).json({ error: 'Sheet is required.' });
      return;
    }

    const system = `You are a Lead Business Intelligence Analyst.
Analyze the provided spreadsheet sheet data and produce a comprehensive executive report.

Return JSON strictly formatted:
{
  "summary": "Executive summary paragraph of findings",
  "keyMetrics": [
    { "label": "Total Value", "value": "R$ 124.500", "trend": "up" },
    { "label": "Average Margin", "value": "34.2%", "trend": "neutral" }
  ],
  "anomalies": ["Highlight any unusual spikes, negative margins, or outliers"],
  "recommendations": ["Actionable step 1", "Actionable step 2"]
}
trend must be one of: up, down, neutral`;

    const user = `Sheet Data:\n${JSON.stringify(sheet.cells ?? sheet, null, 2)}`;
    const text = await callGroq(system, user, { temperature: 0.2 });
    const result = parseJsonSafe(text);
    res.json({ success: true, analysis: result });
  } catch (error: any) {
    console.error('Error in /api/analyze-spreadsheet:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze spreadsheet.' });
  }
});

const PORT = 3000;
export default app;

const isDirectRun =
  process.env.RUN_SERVER === 'true' ||
  (process.argv[1] &&
    (process.argv[1].endsWith('server.cjs') || process.argv[1].endsWith('server.ts')) &&
    !process.argv[1].includes('vite'));

if (isDirectRun) {
  const distPath = path.join(process.cwd(), 'dist');
  app.use(express.static(distPath));
  app.get('*', (req: Request, res: Response) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}
