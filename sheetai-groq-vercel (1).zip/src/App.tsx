import React, { useState } from 'react';
import { Header } from './components/Header';
import { Toolbar } from './components/Toolbar';
import { FormulaBar } from './components/FormulaBar';
import { SpreadsheetGrid } from './components/SpreadsheetGrid';
import { SheetTabs } from './components/SheetTabs';
import { AIPromptModal } from './components/AIPromptModal';
import { AIFormulaModal } from './components/AIFormulaModal';
import { AICommandDrawer } from './components/AICommandDrawer';
import { AIInsightsPanel } from './components/AIInsightsPanel';
import { ChartsView } from './components/ChartsView';
import { TemplatesGalleryModal } from './components/TemplatesGalleryModal';
import { SpreadsheetWorkbook, SheetData, CellStyle, TemplatePreset } from './types/spreadsheet';
import { parseExcelOrCSVFile, exportWorkbookToExcel, exportSheetToCSV } from './utils/excelExporter';
import { parseCellKey, idxToCol } from './utils/formulaEngine';

// Default initial blank workbook
const INITIAL_WORKBOOK: SpreadsheetWorkbook = {
  id: 'wb-demo',
  title: 'Nova Planilha',
  language: 'Portuguese',
  activeSheetId: 'sheet-1',
  sheets: [
    {
      id: 'sheet-1',
      name: 'Planilha 1',
      rowCount: 30,
      colCount: 12,
      cells: {},
    },
  ],
};

export default function App() {
  const [workbook, setWorkbook] = useState<SpreadsheetWorkbook>(INITIAL_WORKBOOK);
  const [selectedCellKey, setSelectedCellKey] = useState<string>('A1');
  const [editingCellKey, setEditingCellKey] = useState<string | null>(null);
  const [formulaBarValue, setFormulaBarValue] = useState<string>('');
  const [language, setLanguage] = useState<string>('Portuguese');

  // Modals & Drawers state
  const [showAIGenerator, setShowAIGenerator] = useState<boolean>(false);
  const [showAIFormula, setShowAIFormula] = useState<boolean>(false);
  const [showAIEditSheet, setShowAIEditSheet] = useState<boolean>(false);
  const [showInsights, setShowInsights] = useState<boolean>(false);
  const [showCharts, setShowCharts] = useState<boolean>(false);
  const [showTemplates, setShowTemplates] = useState<boolean>(false);

  // Loading indicators
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isModifyingSheet, setIsModifyingSheet] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  // Active sheet getter
  const activeSheet =
    workbook.sheets.find((s) => s.id === workbook.activeSheetId) || workbook.sheets[0];

  // Selected cell style getter
  const currentCell = activeSheet.cells[selectedCellKey];
  const currentCellStyle: CellStyle = currentCell?.style || {};

  // Cell Selection Handler
  const handleSelectCell = (key: string) => {
    setSelectedCellKey(key);
    const cell = activeSheet.cells[key];
    const raw = cell?.rawInput !== undefined ? String(cell.rawInput) : cell?.value !== null ? String(cell?.value ?? '') : '';
    setFormulaBarValue(raw);
  };

  // Update Cell Content
  const handleUpdateCell = (
    key: string,
    value: string | number | null,
    rawInput?: string,
    style?: CellStyle
  ) => {
    setWorkbook((prev) => {
      const updatedSheets = prev.sheets.map((sheet) => {
        if (sheet.id !== prev.activeSheetId) return sheet;

        const updatedCells = { ...sheet.cells };
        if (value === null && (!rawInput || rawInput === '')) {
          delete updatedCells[key];
        } else {
          updatedCells[key] = {
            ...updatedCells[key],
            value,
            rawInput: rawInput ?? (value !== null ? String(value) : ''),
            computedValue: value,
            style: style || updatedCells[key]?.style || {},
          };
        }

        return { ...sheet, cells: updatedCells };
      });

      return { ...prev, sheets: updatedSheets };
    });
  };

  // Update Selected Cell Style
  const handleUpdateStyle = (stylePatch: Partial<CellStyle>) => {
    const updatedStyle = { ...currentCellStyle, ...stylePatch };
    const raw = currentCell?.rawInput !== undefined ? String(currentCell.rawInput) : currentCell?.value !== null ? String(currentCell?.value ?? '') : '';
    handleUpdateCell(selectedCellKey, currentCell?.value ?? null, raw, updatedStyle);
  };

  // Insert Row
  const handleInsertRow = (position: 'above' | 'below') => {
    const parsed = parseCellKey(selectedCellKey);
    if (!parsed) return;

    const targetRow = position === 'above' ? parsed.row : parsed.row + 1;

    setWorkbook((prev) => {
      const updatedSheets = prev.sheets.map((sheet) => {
        if (sheet.id !== prev.activeSheetId) return sheet;

        const newCells: Record<string, any> = {};
        Object.keys(sheet.cells).forEach((k) => {
          const p = parseCellKey(k);
          if (!p) return;
          if (p.row >= targetRow) {
            newCells[`${p.col}${p.row + 1}`] = sheet.cells[k];
          } else {
            newCells[k] = sheet.cells[k];
          }
        });

        return { ...sheet, rowCount: sheet.rowCount + 1, cells: newCells };
      });
      return { ...prev, sheets: updatedSheets };
    });
  };

  // Delete Row
  const handleDeleteRow = () => {
    const parsed = parseCellKey(selectedCellKey);
    if (!parsed) return;

    setWorkbook((prev) => {
      const updatedSheets = prev.sheets.map((sheet) => {
        if (sheet.id !== prev.activeSheetId) return sheet;

        const newCells: Record<string, any> = {};
        Object.keys(sheet.cells).forEach((k) => {
          const p = parseCellKey(k);
          if (!p) return;
          if (p.row === parsed.row) {
            // Delete
          } else if (p.row > parsed.row) {
            newCells[`${p.col}${p.row - 1}`] = sheet.cells[k];
          } else {
            newCells[k] = sheet.cells[k];
          }
        });

        return { ...sheet, cells: newCells };
      });
      return { ...prev, sheets: updatedSheets };
    });
  };

  // Insert Column
  const handleInsertColumn = (position: 'left' | 'right') => {
    const parsed = parseCellKey(selectedCellKey);
    if (!parsed) return;

    const targetColIdx = position === 'left' ? parsed.colIdx : parsed.colIdx + 1;

    setWorkbook((prev) => {
      const updatedSheets = prev.sheets.map((sheet) => {
        if (sheet.id !== prev.activeSheetId) return sheet;

        const newCells: Record<string, any> = {};
        Object.keys(sheet.cells).forEach((k) => {
          const p = parseCellKey(k);
          if (!p) return;
          if (p.colIdx >= targetColIdx) {
            newCells[`${idxToCol(p.colIdx + 1)}${p.row}`] = sheet.cells[k];
          } else {
            newCells[k] = sheet.cells[k];
          }
        });

        return { ...sheet, colCount: sheet.colCount + 1, cells: newCells };
      });
      return { ...prev, sheets: updatedSheets };
    });
  };

  // Delete Column
  const handleDeleteColumn = () => {
    const parsed = parseCellKey(selectedCellKey);
    if (!parsed) return;

    setWorkbook((prev) => {
      const updatedSheets = prev.sheets.map((sheet) => {
        if (sheet.id !== prev.activeSheetId) return sheet;

        const newCells: Record<string, any> = {};
        Object.keys(sheet.cells).forEach((k) => {
          const p = parseCellKey(k);
          if (!p) return;
          if (p.colIdx === parsed.colIdx) {
            // Delete
          } else if (p.colIdx > parsed.colIdx) {
            newCells[`${idxToCol(p.colIdx - 1)}${p.row}`] = sheet.cells[k];
          } else {
            newCells[k] = sheet.cells[k];
          }
        });

        return { ...sheet, cells: newCells };
      });
      return { ...prev, sheets: updatedSheets };
    });
  };

  // Generate Spreadsheet via AI
  const handleGenerateSpreadsheet = async (prompt: string, category?: string) => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate-spreadsheet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, category, language }),
      });

      const data = await res.json();
      if (data.success && data.workbook) {
        const wb = data.workbook;
        const formattedSheets = (wb.sheets || []).map((s: any, idx: number) => ({
          id: s.id || `sheet-${Date.now()}-${idx}`,
          name: s.name || `Sheet ${idx + 1}`,
          cells: s.cells || {},
          rowCount: s.rowCount || 30,
          colCount: s.colCount || 12,
          charts: s.charts || [],
        }));

        setWorkbook({
          id: `wb-${Date.now()}`,
          title: wb.title || prompt.slice(0, 30),
          description: wb.description,
          language,
          activeSheetId: formattedSheets[0]?.id || 'sheet-1',
          sheets: formattedSheets.length > 0 ? formattedSheets : INITIAL_WORKBOOK.sheets,
          insights: wb.insights,
        });

        setShowAIGenerator(false);
        if (wb.insights) setShowInsights(true);
      } else {
        alert(data.error || 'Failed to generate spreadsheet.');
      }
    } catch (err: any) {
      alert('Network error during AI generation: ' + err.message);
    } finally {
      setIsGenerating(false);
    }
  };

  // Modify Active Sheet via AI
  const handleModifySheetWithAI = async (command: string) => {
    setIsModifyingSheet(true);
    try {
      const res = await fetch('/api/edit-spreadsheet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sheet: activeSheet,
          command,
          language,
        }),
      });

      const data = await res.json();
      if (data.success && data.updatedSheet) {
        const updated = data.updatedSheet;
        setWorkbook((prev) => ({
          ...prev,
          sheets: prev.sheets.map((s) =>
            s.id === activeSheet.id
              ? {
                  ...s,
                  cells: updated.cells || s.cells,
                  rowCount: updated.rowCount || s.rowCount,
                  colCount: updated.colCount || s.colCount,
                }
              : s
          ),
        }));
      } else {
        alert(data.error || 'Failed to modify sheet.');
      }
    } catch (err: any) {
      alert('Error: ' + err.message);
    } finally {
      setIsModifyingSheet(false);
    }
  };

  // Run AI Executive Data Analysis
  const handleRunAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/analyze-spreadsheet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sheet: activeSheet }),
      });

      const data = await res.json();
      if (data.success && data.analysis) {
        setWorkbook((prev) => ({
          ...prev,
          insights: data.analysis,
        }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Clear Active Sheet Cells
  const handleClearSheet = () => {
    setWorkbook((prev) => ({
      ...prev,
      sheets: prev.sheets.map((sheet) =>
        sheet.id === prev.activeSheetId
          ? { ...sheet, cells: {} }
          : sheet
      ),
      insights: undefined,
    }));
    setFormulaBarValue('');
  };

  // Import File Handler
  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const importedWb = await parseExcelOrCSVFile(file);
      setWorkbook(importedWb);
    } catch (err: any) {
      alert('Failed to parse file: ' + err.message);
    }
  };

  // Export File Handlers
  const handleExportExcel = () => {
    exportWorkbookToExcel(workbook, workbook.title);
  };

  const handleExportCSV = () => {
    exportSheetToCSV(activeSheet, `${workbook.title}_${activeSheet.name}`);
  };

  // Add Sheet
  const handleAddSheet = () => {
    const newId = `sheet-${Date.now()}`;
    const newName = `Sheet ${workbook.sheets.length + 1}`;
    const newSheet: SheetData = {
      id: newId,
      name: newName,
      cells: {},
      rowCount: 30,
      colCount: 12,
    };
    setWorkbook((prev) => ({
      ...prev,
      sheets: [...prev.sheets, newSheet],
      activeSheetId: newId,
    }));
  };

  // Rename Sheet
  const handleRenameSheet = (id: string, newName: string) => {
    setWorkbook((prev) => ({
      ...prev,
      sheets: prev.sheets.map((s) => (s.id === id ? { ...s, name: newName } : s)),
    }));
  };

  // Delete Sheet
  const handleDeleteSheet = (id: string) => {
    if (workbook.sheets.length <= 1) return;
    setWorkbook((prev) => {
      const filtered = prev.sheets.filter((s) => s.id !== id);
      return {
        ...prev,
        sheets: filtered,
        activeSheetId: filtered[0].id,
      };
    });
  };

  // Duplicate Sheet
  const handleDuplicateSheet = (id: string) => {
    const target = workbook.sheets.find((s) => s.id === id);
    if (!target) return;

    const newId = `sheet-${Date.now()}`;
    const duplicated: SheetData = {
      ...target,
      id: newId,
      name: `${target.name} (Copy)`,
      cells: JSON.parse(JSON.stringify(target.cells)),
    };

    setWorkbook((prev) => ({
      ...prev,
      sheets: [...prev.sheets, duplicated],
      activeSheetId: newId,
    }));
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 font-sans overflow-hidden select-none">
      {/* App Header */}
      <Header
        workbook={workbook}
        onUpdateTitle={(newTitle) => setWorkbook((prev) => ({ ...prev, title: newTitle }))}
        onOpenAIGenerator={() => setShowAIGenerator(true)}
        onOpenTemplates={() => setShowTemplates(true)}
        onImportFile={handleImportFile}
        onExportExcel={handleExportExcel}
        onExportCSV={handleExportCSV}
        onToggleInsights={() => {
          setShowInsights(!showInsights);
          if (!workbook.insights) handleRunAnalysis();
        }}
        onToggleCharts={() => setShowCharts(!showCharts)}
        showInsights={showInsights}
        showCharts={showCharts}
        language={language}
        onChangeLanguage={(lang) => setLanguage(lang)}
      />

      {/* Formatting Toolbar */}
      <Toolbar
        currentStyle={currentCellStyle}
        onUpdateStyle={handleUpdateStyle}
        onInsertRow={handleInsertRow}
        onDeleteRow={handleDeleteRow}
        onInsertColumn={handleInsertColumn}
        onDeleteColumn={handleDeleteColumn}
        onOpenAIFormula={() => setShowAIFormula(true)}
        onOpenAIEditSheet={() => setShowAIEditSheet(true)}
        onClearSheet={handleClearSheet}
        language={language}
      />

      {/* Formula Input Bar */}
      <FormulaBar
        selectedCellKey={selectedCellKey}
        rawValue={formulaBarValue}
        onChangeRawValue={(val) => {
          setFormulaBarValue(val);
          handleUpdateCell(selectedCellKey, val.startsWith('=') ? null : val, val, currentCellStyle);
        }}
        onCommit={() => {
          setEditingCellKey(null);
        }}
        onCancel={() => {
          const raw = currentCell?.rawInput !== undefined ? String(currentCell.rawInput) : currentCell?.value !== null ? String(currentCell?.value ?? '') : '';
          setFormulaBarValue(raw);
          setEditingCellKey(null);
        }}
        onOpenAIFormula={() => setShowAIFormula(true)}
      />

      {/* Visual Charts Container (Toggleable) */}
      {showCharts && (
        <ChartsView sheet={activeSheet} onClose={() => setShowCharts(false)} />
      )}

      {/* Main Interactive Spreadsheet Grid */}
      <SpreadsheetGrid
        sheet={activeSheet}
        selectedCellKey={selectedCellKey}
        onSelectCell={handleSelectCell}
        onUpdateCell={handleUpdateCell}
        editingCellKey={editingCellKey}
        setEditingCellKey={setEditingCellKey}
      />

      {/* Workbook Sheet Tabs */}
      <SheetTabs
        sheets={workbook.sheets}
        activeSheetId={activeSheet.id}
        onSelectSheet={(id) => setWorkbook((prev) => ({ ...prev, activeSheetId: id }))}
        onAddSheet={handleAddSheet}
        onRenameSheet={handleRenameSheet}
        onDeleteSheet={handleDeleteSheet}
        onDuplicateSheet={handleDuplicateSheet}
      />

      {/* AI Modals and Drawers */}
      <AIPromptModal
        isOpen={showAIGenerator}
        onClose={() => setShowAIGenerator(false)}
        onGenerate={handleGenerateSpreadsheet}
        isLoading={isGenerating}
        language={language}
      />

      <AIFormulaModal
        isOpen={showAIFormula}
        onClose={() => setShowAIFormula(false)}
        targetCellKey={selectedCellKey}
        onApplyFormula={(formula) => {
          handleUpdateCell(selectedCellKey, null, formula, currentCellStyle);
          setFormulaBarValue(formula);
        }}
        language={language}
      />

      <AICommandDrawer
        isOpen={showAIEditSheet}
        onClose={() => setShowAIEditSheet(false)}
        activeSheet={activeSheet}
        onModifySheet={handleModifySheetWithAI}
        isLoading={isModifyingSheet}
        language={language}
      />

      <AIInsightsPanel
        isOpen={showInsights}
        onClose={() => setShowInsights(false)}
        workbook={workbook}
        activeSheet={activeSheet}
        onRunAnalysis={handleRunAnalysis}
        isAnalyzing={isAnalyzing}
      />

      <TemplatesGalleryModal
        isOpen={showTemplates}
        onClose={() => setShowTemplates(false)}
        onSelectTemplate={(tmpl: TemplatePreset) => {
          handleGenerateSpreadsheet(tmpl.prompt, tmpl.category);
        }}
      />
    </div>
  );
}
