import React, { useState } from 'react';
import { Sparkles, X, Loader2, Send, CheckCircle2 } from 'lucide-react';
import { SheetData } from '../types/spreadsheet';

interface AICommandDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeSheet: SheetData;
  onModifySheet: (command: string) => Promise<void>;
  isLoading: boolean;
  language: string;
}

const SAMPLE_COMMANDS_PT = [
  'Adicionar coluna de previsão 2026 com crescimento de 12% sobre 2025',
  'Adicionar linha de totalização no rodapé com fórmulas =SUM()',
  'Formatar linha de cabeçalho com fundo azul escuro e texto em negrito',
  'Calcular coluna de margem de lucro % (=Lucro/Receita)',
  'Adicionar coluna de imposto ISS/ICMS de 5%',
];

const SAMPLE_COMMANDS_EN = [
  'Add a 2026 forecast column with 12% growth over 2025',
  'Add a total summary row at the bottom with =SUM() formulas',
  'Format header row with dark blue fill and white bold text',
  'Calculate profit margin percentage column (=Profit/Revenue)',
  'Add a 5% VAT tax column',
];

export const AICommandDrawer: React.FC<AICommandDrawerProps> = ({
  isOpen,
  onClose,
  activeSheet,
  onModifySheet,
  isLoading,
  language,
}) => {
  const [command, setCommand] = useState('');
  const [lastMessage, setLastMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const commands = language === 'Portuguese' ? SAMPLE_COMMANDS_PT : SAMPLE_COMMANDS_EN;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim() || isLoading) return;

    const currentCmd = command.trim();
    setCommand('');
    await onModifySheet(currentCmd);
    setLastMessage(language === 'Portuguese' ? `Aplicado: "${currentCmd}"` : `Applied: "${currentCmd}"`);
  };

  return (
    <div className="fixed right-0 top-0 bottom-0 w-80 sm:w-96 bg-slate-900 border-l border-slate-800 shadow-2xl z-40 flex flex-col p-4 text-white">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <div>
            <h3 className="text-sm font-bold">
              {language === 'Portuguese' ? 'Modificador de Planilha com IA' : 'AI Sheet Modifier'}
            </h3>
            <p className="text-[11px] text-slate-400">
              {language === 'Portuguese' ? `Transformar aba ativa: ${activeSheet.name}` : `Transform active sheet: ${activeSheet.name}`}
            </p>
          </div>
        </div>
        <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Message Feedback */}
      {lastMessage && (
        <div className="mt-3 p-2.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs rounded-lg flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{lastMessage}</span>
        </div>
      )}

      {/* Suggested Quick Commands */}
      <div className="flex-1 overflow-y-auto my-4 space-y-3">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
          {language === 'Portuguese' ? 'Transformações Sugeridas' : 'Suggested Transformations'}
        </span>
        <div className="space-y-2">
          {commands.map((cmd, idx) => (
            <button
              key={idx}
              onClick={() => {
                setCommand(cmd);
              }}
              className="w-full text-left p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-lg text-xs text-slate-300 transition-colors"
            >
              {cmd}
            </button>
          ))}
        </div>
      </div>

      {/* Command Input Form */}
      <form onSubmit={handleSubmit} className="space-y-2 border-t border-slate-800 pt-3">
        <div className="relative">
          <input
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            placeholder={
              language === 'Portuguese'
                ? 'Digite um comando (ex: Adicionar coluna de impostos...)'
                : 'Type command (e.g. Add VAT column...)'
            }
            disabled={isLoading}
            className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 text-white placeholder-slate-500 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none pr-10"
          />
          <button
            type="submit"
            disabled={!command.trim() || isLoading}
            className="absolute right-2 top-2 p-1 text-amber-400 hover:text-amber-300 disabled:opacity-40"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>
        <p className="text-[10px] text-slate-500 text-center">Language: {language}</p>
      </form>
    </div>
  );
};
