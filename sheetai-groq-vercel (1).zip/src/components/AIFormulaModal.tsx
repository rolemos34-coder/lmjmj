import React, { useState } from 'react';
import { Wand2, X, Loader2, Check, HelpCircle } from 'lucide-react';

interface AIFormulaModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetCellKey: string;
  onApplyFormula: (formula: string, explanation?: string) => void;
  language: string;
}

export const AIFormulaModal: React.FC<AIFormulaModalProps> = ({
  isOpen,
  onClose,
  targetCellKey,
  onApplyFormula,
  language,
}) => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ formula: string; explanation: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch('/api/ai-formula-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          targetCell: targetCellKey,
          language,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setResult({
          formula: data.formula,
          explanation: data.explanation,
        });
      } else {
        setError(data.error || 'Could not generate formula.');
      }
    } catch (err: any) {
      setError(err.message || 'Network request failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    if (result) {
      onApplyFormula(result.formula, result.explanation);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden p-5 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl">
              <Wand2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {language === 'Portuguese' ? 'Assistente de Fórmulas IA' : 'AI Formula Assistant'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'Portuguese' ? 'Célula Destino: ' : 'Target Cell: '}
                <span className="font-mono text-indigo-400 font-bold">{targetCellKey}</span>
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Input */}
        <form onSubmit={handleGenerate} className="space-y-3">
          <label className="block text-xs font-semibold text-slate-300">
            {language === 'Portuguese'
              ? 'O que você quer que a fórmula desta célula calcule?'
              : 'What do you want this cell formula to compute?'}
          </label>
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              language === 'Portuguese'
                ? 'ex: Calcular 15% de imposto sobre o subtotal na célula B10'
                : 'e.g., Calculate 15% VAT on subtotal in cell B10'
            }
            className="w-full bg-slate-950 border border-slate-800 text-white placeholder-slate-500 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-indigo-500 font-sans"
          />

          <button
            type="submit"
            disabled={!prompt.trim() || isLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-medium text-xs py-2 rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <span>{language === 'Portuguese' ? 'Gerar Fórmula' : 'Generate Formula'}</span>
            )}
          </button>
        </form>

        {/* Output Preview */}
        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl">
            {error}
          </div>
        )}

        {result && (
          <div className="p-4 bg-slate-950 border border-indigo-500/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase text-indigo-400 tracking-wider">
                {language === 'Portuguese' ? 'Pré-visualização da Fórmula' : 'Formula Preview'}
              </span>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-mono">
                {targetCellKey}
              </span>
            </div>

            <div className="bg-slate-900 p-2.5 rounded-lg font-mono text-emerald-400 text-sm font-bold border border-slate-800">
              {result.formula}
            </div>

            <p className="text-xs text-slate-300 flex items-start gap-1.5">
              <HelpCircle className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
              <span>{result.explanation}</span>
            </p>

            <button
              onClick={handleApply}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-2 rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>
                {language === 'Portuguese' ? `Inserir Fórmula em ${targetCellKey}` : `Insert Formula into ${targetCellKey}`}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
