import React from 'react';
import { BrainCircuit, X, TrendingUp, TrendingDown, Lightbulb, AlertTriangle, RefreshCw, Loader2, FunctionSquare } from 'lucide-react';
import { SpreadsheetWorkbook, SheetData } from '../types/spreadsheet';

interface AIInsightsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  workbook: SpreadsheetWorkbook;
  activeSheet: SheetData;
  onRunAnalysis: () => Promise<void>;
  isAnalyzing: boolean;
}

export const AIInsightsPanel: React.FC<AIInsightsPanelProps> = ({
  isOpen,
  onClose,
  workbook,
  activeSheet,
  onRunAnalysis,
  isAnalyzing,
}) => {
  if (!isOpen) return null;

  const insights = workbook.insights;

  return (
    <div className="fixed right-0 top-0 bottom-0 w-80 sm:w-96 bg-slate-900 border-l border-slate-800 shadow-2xl z-40 flex flex-col p-4 text-white overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-5 h-5 text-purple-400" />
          <div>
            <h3 className="text-sm font-bold">AI Executive Analysis</h3>
            <p className="text-[11px] text-slate-400">{activeSheet.name}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={onRunAnalysis}
            disabled={isAnalyzing}
            className="p-1.5 text-slate-400 hover:text-purple-300 hover:bg-slate-800 rounded transition-colors"
            title="Refresh Analysis"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin text-purple-400" /> : <RefreshCw className="w-4 h-4" />}
          </button>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Body Content */}
      <div className="mt-4 space-y-4 flex-1">
        {/* Executive Summary */}
        <div className="p-3.5 bg-slate-950 border border-purple-500/20 rounded-xl space-y-1.5">
          <span className="text-[10px] font-bold uppercase text-purple-400 tracking-wider">Visão Geral Executiva</span>
          <p className="text-xs text-slate-300 leading-relaxed">
            {insights?.summary || 'Gere ou edite sua planilha para receber relatórios e análises executivas automatizadas.'}
          </p>
        </div>

        {/* Key Metrics Grid */}
        {insights?.keyMetrics && insights.keyMetrics.length > 0 && (
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Indicadores-Chave (KPIs)</span>
            <div className="grid grid-cols-2 gap-2">
              {insights.keyMetrics.map((metric, idx) => (
                <div key={idx} className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 block truncate">{metric.label}</span>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">{metric.value}</span>
                    {metric.trend === 'up' && <TrendingUp className="w-4 h-4 text-emerald-400" />}
                    {metric.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-400" />}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recommendations */}
        {insights?.recommendations && insights.recommendations.length > 0 && (
          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <span className="text-[10px] font-bold uppercase text-amber-400 tracking-wider flex items-center gap-1">
              <Lightbulb className="w-3.5 h-3.5" />
              Recomendações Estratégicas
            </span>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {insights.recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-amber-400 font-bold">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Formulas Explanation */}
        {insights?.formulasUsed && insights.formulasUsed.length > 0 && (
          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <span className="text-[10px] font-bold uppercase text-indigo-400 tracking-wider flex items-center gap-1">
              <FunctionSquare className="w-3.5 h-3.5" />
              Cálculos Principais de Fórmulas
            </span>
            <div className="space-y-2">
              {insights.formulasUsed.map((f, i) => (
                <div key={i} className="bg-slate-900 p-2 rounded border border-slate-800 space-y-0.5">
                  <span className="text-emerald-400 font-mono text-xs font-bold block">{f.formula}</span>
                  <span className="text-[11px] text-slate-400 block">{f.purpose}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
