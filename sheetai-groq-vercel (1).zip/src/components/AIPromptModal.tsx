import React, { useState } from 'react';
import { Sparkles, X, Loader2, ArrowRight, Lightbulb, Compass } from 'lucide-react';
import { STARTER_TEMPLATES } from '../data/templates';

interface AIPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (prompt: string, category?: string) => Promise<void>;
  isLoading: boolean;
  language: string;
}

export const AIPromptModal: React.FC<AIPromptModalProps> = ({
  isOpen,
  onClose,
  onGenerate,
  isLoading,
  language,
}) => {
  const [promptInput, setPromptInput] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (promptInput.trim() && !isLoading) {
      onGenerate(promptInput.trim(), selectedCategory !== 'All' ? selectedCategory : undefined);
    }
  };

  const handleSelectTemplate = (prompt: string, category: string) => {
    setPromptInput(prompt);
    setSelectedCategory(category);
  };

  const categories = ['All', 'Finance & Accounting', 'Marketing & Sales', 'Project Management', 'Personal Finance', 'HR & Operations'];

  const filteredTemplates = selectedCategory === 'All'
    ? STARTER_TEMPLATES
    : STARTER_TEMPLATES.filter(t => t.category === selectedCategory);

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                {language === 'Portuguese' ? 'Gerar Planilha com IA' : 'Generate Spreadsheet with AI'}
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'Portuguese'
                  ? 'Descreva qualquer modelo, orçamento, controle ou relatório para criar instantaneamente'
                  : 'Describe any model, budget, tracker, or report to build instantly'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isLoading}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              {language === 'Portuguese' ? 'O que você deseja gerar?' : 'What do you want to generate?'} ({language})
            </label>
            <div className="relative">
              <textarea
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder={
                  language === 'Portuguese'
                    ? 'ex: Crie um modelo financeiro de 12 meses com MRR, Churn, LTV, CAC, Despesas, Margem Bruta e Lucro Líquido com fórmulas SOMA e %...'
                    : 'e.g., Create a 12-month SaaS Financial Projection with MRR, Churn, LTV, CAC, OpEx, Gross Margin %, and Net Profit with SUM and % formulas...'
                }
                rows={4}
                disabled={isLoading}
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 text-white placeholder-slate-500 rounded-xl p-3.5 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all resize-none font-sans"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                {language === 'Portuguese'
                  ? 'Inclua cabeçalhos, métricas e lógica de fórmulas desejada para melhores resultados'
                  : 'Include headers, metrics, and desired formula logic for best results'}
              </span>

              <button
                type="submit"
                disabled={!promptInput.trim() || isLoading}
                className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50 text-white font-medium text-xs px-5 py-2.5 rounded-xl shadow-lg transition-all transform active:scale-95"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>{language === 'Portuguese' ? 'Gerando Modelo...' : 'Generating Model...'}</span>
                  </>
                ) : (
                  <>
                    <span>{language === 'Portuguese' ? 'Criar Planilha' : 'Build Spreadsheet'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Quick Category Filter Chips */}
          <div className="pt-2 border-t border-slate-800">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
              <Compass className="w-4 h-4 text-slate-500 mr-1 flex-shrink-0" />
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                    selectedCategory === cat
                      ? 'bg-emerald-500 text-slate-950 font-semibold'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Starter Presets List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-3">
              {filteredTemplates.map((tmpl) => (
                <div
                  key={tmpl.id}
                  onClick={() => handleSelectTemplate(tmpl.prompt, tmpl.category)}
                  className="p-3 bg-slate-950/60 hover:bg-slate-800/80 border border-slate-800 hover:border-emerald-500/50 rounded-xl cursor-pointer transition-all group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 transition-colors">
                      {tmpl.title}
                    </span>
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                      {tmpl.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2">{tmpl.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
