import React, { useState } from 'react';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { SheetData } from '../types/spreadsheet';
import { idxToCol, colToIdx, parseCellKey } from '../utils/formulaEngine';
import { BarChart2, LineChart as LineIcon, PieChart as PieIcon, AreaChart as AreaIcon, X } from 'lucide-react';

interface ChartsViewProps {
  sheet: SheetData;
  onClose: () => void;
}

const COLORS = ['#10b981', '#6366f1', '#f59e0b', '#ec4899', '#3b82f6', '#8b5cf6'];

export const ChartsView: React.FC<ChartsViewProps> = ({ sheet, onClose }) => {
  const [chartType, setChartType] = useState<'bar' | 'line' | 'area' | 'pie'>('bar');
  const [xAxisCol, setXAxisCol] = useState<string>('A');
  const [dataCols, setDataCols] = useState<string[]>(['B', 'C']);

  // Build JSON dataset from active sheet cells
  const buildChartDataset = () => {
    const dataset: Record<string, any>[] = [];
    const maxRows = Math.min(sheet.rowCount || 30, 25);

    for (let r = 2; r <= maxRows; r++) {
      const xKey = `${xAxisCol}${r}`;
      const xCell = sheet.cells[xKey];
      const xLabel = xCell ? String(xCell.computedValue ?? xCell.value ?? `Row ${r}`) : `Row ${r}`;

      const rowObj: Record<string, any> = { name: xLabel };
      let hasData = false;

      for (const colLet of dataCols) {
        const cellKey = `${colLet}${r}`;
        const cell = sheet.cells[cellKey];
        const headerCell = sheet.cells[`${colLet}1`];
        const seriesName = headerCell ? String(headerCell.computedValue ?? headerCell.value ?? `Col ${colLet}`) : `Col ${colLet}`;

        if (cell && typeof (cell.computedValue ?? cell.value) === 'number') {
          rowObj[seriesName] = cell.computedValue ?? cell.value;
          hasData = true;
        } else if (cell && cell.value && !isNaN(Number(cell.value))) {
          rowObj[seriesName] = Number(cell.value);
          hasData = true;
        }
      }

      if (hasData) {
        dataset.push(rowObj);
      }
    }

    return dataset;
  };

  const dataset = buildChartDataset();
  const seriesKeys = dataset.length > 0 ? Object.keys(dataset[0]).filter(k => k !== 'name') : [];

  return (
    <div className="bg-slate-900 border-b border-slate-800 p-4 text-white space-y-4">
      {/* Chart Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-amber-400" />
          <div>
            <h3 className="text-sm font-bold">Data Visualization</h3>
            <p className="text-xs text-slate-400">{sheet.name} Visual Charts</p>
          </div>
        </div>

        {/* Chart Type Picker */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setChartType('bar')}
            className={`p-1.5 rounded text-xs flex items-center gap-1 ${
              chartType === 'bar' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <BarChart2 className="w-4 h-4" /> Bar
          </button>
          <button
            onClick={() => setChartType('line')}
            className={`p-1.5 rounded text-xs flex items-center gap-1 ${
              chartType === 'line' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <LineIcon className="w-4 h-4" /> Line
          </button>
          <button
            onClick={() => setChartType('area')}
            className={`p-1.5 rounded text-xs flex items-center gap-1 ${
              chartType === 'area' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <AreaIcon className="w-4 h-4" /> Area
          </button>
          <button
            onClick={() => setChartType('pie')}
            className={`p-1.5 rounded text-xs flex items-center gap-1 ${
              chartType === 'pie' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <PieIcon className="w-4 h-4" /> Pie
          </button>
        </div>

        {/* X-Axis & Data Column Selectors */}
        <div className="flex items-center gap-2 text-xs">
          <label className="text-slate-400">X-Axis:</label>
          <select
            value={xAxisCol}
            onChange={(e) => setXAxisCol(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-white px-2 py-1 rounded text-xs focus:outline-none"
          >
            {['A', 'B', 'C', 'D', 'E', 'F'].map(c => (
              <option key={c} value={c}>Column {c}</option>
            ))}
          </select>

          <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white ml-2">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Render Chart Container */}
      <div className="h-72 w-full bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-center">
        {dataset.length === 0 ? (
          <div className="text-slate-500 text-xs">No numeric chart data found in active range.</div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'bar' ? (
              <BarChart data={dataset}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                <Legend />
                {seriesKeys.map((sKey, idx) => (
                  <Bar key={sKey} dataKey={sKey} fill={COLORS[idx % COLORS.length]} radius={[4, 4, 0, 0]} />
                ))}
              </BarChart>
            ) : chartType === 'line' ? (
              <LineChart data={dataset}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                <Legend />
                {seriesKeys.map((sKey, idx) => (
                  <Line key={sKey} type="monotone" dataKey={sKey} stroke={COLORS[idx % COLORS.length]} strokeWidth={2} />
                ))}
              </LineChart>
            ) : chartType === 'area' ? (
              <AreaChart data={dataset}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                <Legend />
                {seriesKeys.map((sKey, idx) => (
                  <Area key={sKey} type="monotone" dataKey={sKey} fill={COLORS[idx % COLORS.length]} stroke={COLORS[idx % COLORS.length]} opacity={0.6} />
                ))}
              </AreaChart>
            ) : (
              <PieChart>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                <Legend />
                <Pie
                  data={dataset}
                  dataKey={seriesKeys[0] || 'value'}
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label
                >
                  {dataset.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            )}
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};
