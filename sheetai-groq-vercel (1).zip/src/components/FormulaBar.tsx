import React from 'react';
import { FunctionSquare, Check, X } from 'lucide-react';

interface FormulaBarProps {
  selectedCellKey: string;
  rawValue: string;
  onChangeRawValue: (val: string) => void;
  onCommit: () => void;
  onCancel: () => void;
  onOpenAIFormula: () => void;
}

const COMMON_FUNCTIONS = ['SUM', 'AVERAGE', 'IF', 'COUNT', 'MIN', 'MAX'];

export const FormulaBar: React.FC<FormulaBarProps> = ({
  selectedCellKey,
  rawValue,
  onChangeRawValue,
  onCommit,
  onCancel,
  onOpenAIFormula,
}) => {
  const insertFunction = (funcName: string) => {
    if (!rawValue.startsWith('=')) {
      onChangeRawValue(`=${funcName}()`);
    } else {
      onChangeRawValue(`${rawValue}${funcName}()`);
    }
  };

  return (
    <div className="bg-white border-b border-slate-300 px-3 py-1.5 flex items-center gap-2 text-slate-800 text-xs">
      {/* Active Cell Reference */}
      <div className="w-16 h-7 bg-slate-100 border border-slate-300 rounded font-mono font-bold flex items-center justify-center text-slate-700 shadow-inner">
        {selectedCellKey || 'A1'}
      </div>

      {/* fx button */}
      <button
        onClick={onOpenAIFormula}
        className="h-7 px-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded font-semibold flex items-center gap-1 transition-colors"
        title="Abrir Assistente de Fórmulas com IA"
      >
        <FunctionSquare className="w-4 h-4 text-indigo-600" />
        <span>fx</span>
      </button>

      {/* Formula Input */}
      <div className="flex-1 flex items-center gap-1 border border-slate-300 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500 rounded px-2 bg-white h-7">
        <span className="text-slate-400 font-mono font-semibold select-none">=</span>
        <input
          type="text"
          value={rawValue.startsWith('=') ? rawValue.substring(1) : rawValue}
          onChange={(e) => {
            const val = e.target.value;
            if (rawValue.startsWith('=')) {
              onChangeRawValue(`=${val}`);
            } else {
              onChangeRawValue(val.startsWith('=') ? val : val);
            }
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter') onCommit();
            if (e.key === 'Escape') onCancel();
          }}
          placeholder="Digite um valor ou fórmula (ex: SUM(B2:B10) ou =B2*0,15)"
          className="w-full h-full bg-transparent text-slate-900 focus:outline-none text-xs font-mono"
        />
      </div>

      {/* Commit / Cancel Controls */}
      <div className="flex items-center gap-1">
        <button
          onClick={onCommit}
          className="p-1 hover:bg-emerald-100 text-emerald-700 rounded"
          title="Accept (Enter)"
        >
          <Check className="w-4 h-4" />
        </button>
        <button
          onClick={onCancel}
          className="p-1 hover:bg-red-100 text-red-600 rounded"
          title="Cancel (Esc)"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Function Chips */}
      <div className="hidden lg:flex items-center gap-1 pl-2 border-l border-slate-300">
        <span className="text-[10px] text-slate-400 font-medium mr-1">Quick:</span>
        {COMMON_FUNCTIONS.map((fn) => (
          <button
            key={fn}
            onClick={() => insertFunction(fn)}
            className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[10px] font-mono border border-slate-200"
          >
            {fn}
          </button>
        ))}
      </div>
    </div>
  );
};
