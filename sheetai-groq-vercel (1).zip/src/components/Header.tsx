import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Sparkles,
  Download,
  Upload,
  LayoutTemplate,
  BarChart2,
  BrainCircuit,
  Globe,
  ChevronDown,
  Check,
  Table,
} from 'lucide-react';
import { SpreadsheetWorkbook } from '../types/spreadsheet';

interface HeaderProps {
  workbook: SpreadsheetWorkbook;
  onUpdateTitle: (title: string) => void;
  onOpenAIGenerator: () => void;
  onOpenTemplates: () => void;
  onImportFile: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onExportExcel: () => void;
  onExportCSV: () => void;
  onToggleInsights: () => void;
  onToggleCharts: () => void;
  showInsights: boolean;
  showCharts: boolean;
  language: string;
  onChangeLanguage: (lang: string) => void;
}

const LANGUAGES = [
  { code: 'Portuguese', label: 'Português (BR/PT)' },
  { code: 'English', label: 'English (US)' },
  { code: 'Spanish', label: 'Español' },
  { code: 'French', label: 'Français' },
  { code: 'German', label: 'Deutsch' },
];

export const Header: React.FC<HeaderProps> = ({
  workbook,
  onUpdateTitle,
  onOpenAIGenerator,
  onOpenTemplates,
  onImportFile,
  onExportExcel,
  onExportCSV,
  onToggleInsights,
  onToggleCharts,
  showInsights,
  showCharts,
  language,
  onChangeLanguage,
}) => {
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(workbook.title);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const handleTitleSubmit = () => {
    setIsEditingTitle(false);
    if (titleInput.trim()) {
      onUpdateTitle(titleInput.trim());
    } else {
      setTitleInput(workbook.title);
    }
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-md">
      {/* Left: Brand & Workbook Name */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 px-3 py-1.5 rounded-lg font-semibold text-sm">
          <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
          <span>SheetAI</span>
          <span className="bg-emerald-500/20 text-emerald-300 text-[10px] px-1.5 py-0.5 rounded font-mono uppercase tracking-wider">
            AI Excel
          </span>
        </div>

        <div className="h-5 w-[1px] bg-slate-700 hidden sm:block" />

        <div className="flex items-center gap-2">
          {isEditingTitle ? (
            <input
              type="text"
              value={titleInput}
              onChange={(e) => setTitleInput(e.target.value)}
              onBlur={handleTitleSubmit}
              onKeyDown={(e) => e.key === 'Enter' && handleTitleSubmit()}
              autoFocus
              className="bg-slate-800 border border-slate-600 text-white text-sm px-2.5 py-1 rounded focus:outline-none focus:border-emerald-500"
            />
          ) : (
            <button
              onClick={() => {
                setTitleInput(workbook.title);
                setIsEditingTitle(true);
              }}
              className="text-slate-100 hover:text-emerald-400 font-medium text-sm px-2 py-1 rounded hover:bg-slate-800 transition-colors flex items-center gap-1.5"
              title="Click to rename"
            >
              <span>{workbook.title || 'Untitled Spreadsheet'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Middle/Right Controls */}
      <div className="flex items-center flex-wrap gap-2">
        {/* Language Picker */}
        <div className="relative">
          <button
            onClick={() => setShowLangMenu(!showLangMenu)}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-2.5 py-1.5 rounded-md border border-slate-700 transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span>{language}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {showLangMenu && (
            <div className="absolute right-0 mt-1 w-44 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 py-1 text-xs">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    onChangeLanguage(lang.code);
                    setShowLangMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-700 flex items-center justify-between"
                >
                  <span>{lang.label}</span>
                  {language === lang.code && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Templates */}
        <button
          onClick={onOpenTemplates}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-2.5 py-1.5 rounded-md border border-slate-700 transition-colors"
          title={language === 'Portuguese' ? 'Navegar por modelos de planilhas' : 'Browse Pre-made Spreadsheet Templates'}
        >
          <LayoutTemplate className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden sm:inline">{language === 'Portuguese' ? 'Modelos' : 'Templates'}</span>
        </button>

        {/* Generate with AI Button */}
        <button
          onClick={onOpenAIGenerator}
          className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-medium text-xs px-3.5 py-1.5 rounded-md shadow-sm transition-all transform active:scale-95"
        >
          <Sparkles className="w-4 h-4 text-emerald-100 animate-pulse" />
          <span>{language === 'Portuguese' ? 'Gerar com IA' : 'Generate with AI'}</span>
        </button>

        {/* Import File */}
        <label className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-2.5 py-1.5 rounded-md border border-slate-700 transition-colors cursor-pointer">
          <Upload className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden sm:inline">{language === 'Portuguese' ? 'Importar' : 'Import'}</span>
          <input
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={onImportFile}
            className="hidden"
          />
        </label>

        {/* Export Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowExportMenu(!showExportMenu)}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-2.5 py-1.5 rounded-md border border-slate-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>{language === 'Portuguese' ? 'Exportar' : 'Export'}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {showExportMenu && (
            <div className="absolute right-0 mt-1 w-52 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 py-1 text-xs">
              <button
                onClick={() => {
                  onExportExcel();
                  setShowExportMenu(false);
                }}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-700 flex items-center gap-2"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span>{language === 'Portuguese' ? 'Exportar Excel (.xlsx)' : 'Export as Excel (.xlsx)'}</span>
              </button>
              <button
                onClick={() => {
                  onExportCSV();
                  setShowExportMenu(false);
                }}
                className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-700 flex items-center gap-2"
              >
                <Table className="w-4 h-4 text-sky-400" />
                <span>{language === 'Portuguese' ? 'Exportar aba ativa (.csv)' : 'Export active sheet (.csv)'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Toggle Charts */}
        <button
          onClick={onToggleCharts}
          className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border transition-colors ${
            showCharts
              ? 'bg-amber-500/20 border-amber-500 text-amber-300'
              : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
          }`}
          title={language === 'Portuguese' ? 'Alternar gráficos visuais' : 'Toggle Visual Charts'}
        >
          <BarChart2 className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline">{language === 'Portuguese' ? 'Gráficos' : 'Charts'}</span>
        </button>

        {/* Toggle AI Insights */}
        <button
          onClick={onToggleInsights}
          className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border transition-colors ${
            showInsights
              ? 'bg-purple-500/20 border-purple-500 text-purple-300'
              : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
          }`}
          title={language === 'Portuguese' ? 'Análise executiva e insights com IA' : 'AI Insights & Executive Analysis'}
        >
          <BrainCircuit className="w-3.5 h-3.5 text-purple-400" />
          <span className="hidden md:inline">{language === 'Portuguese' ? 'Análise IA' : 'AI Analysis'}</span>
        </button>
      </div>
    </header>
  );
};
