import React, { useState } from 'react';
import { Plus, X, Copy, Edit2 } from 'lucide-react';
import { SheetData } from '../types/spreadsheet';

interface SheetTabsProps {
  sheets: SheetData[];
  activeSheetId: string;
  onSelectSheet: (id: string) => void;
  onAddSheet: () => void;
  onRenameSheet: (id: string, newName: string) => void;
  onDeleteSheet: (id: string) => void;
  onDuplicateSheet: (id: string) => void;
}

export const SheetTabs: React.FC<SheetTabsProps> = ({
  sheets,
  activeSheetId,
  onSelectSheet,
  onAddSheet,
  onRenameSheet,
  onDeleteSheet,
  onDuplicateSheet,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState<string>('');

  const handleStartRename = (sheet: SheetData) => {
    setEditingId(sheet.id);
    setEditName(sheet.name);
  };

  const handleSaveRename = (id: string) => {
    if (editName.trim()) {
      onRenameSheet(id, editName.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="bg-slate-800 border-t border-slate-700 px-2 py-1 flex items-center justify-between gap-2 overflow-x-auto text-xs text-slate-300 select-none">
      <div className="flex items-center gap-1 overflow-x-auto py-0.5">
        {sheets.map((s) => {
          const isActive = s.id === activeSheetId;
          const isEditing = editingId === s.id;

          return (
            <div
              key={s.id}
              onClick={() => onSelectSheet(s.id)}
              onDoubleClick={() => handleStartRename(s)}
              className={`group flex items-center gap-1.5 px-3 py-1 rounded-t-md font-medium cursor-pointer transition-colors border-t-2 ${
                isActive
                  ? 'bg-white text-slate-900 border-emerald-500 font-semibold shadow-sm'
                  : 'bg-slate-700/60 hover:bg-slate-700 text-slate-300 border-transparent'
              }`}
            >
              {isEditing ? (
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  onBlur={() => handleSaveRename(s.id)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSaveRename(s.id)}
                  autoFocus
                  className="bg-slate-100 text-slate-900 px-1 py-0.5 text-xs rounded border border-emerald-500 focus:outline-none w-24"
                />
              ) : (
                <span>{s.name}</span>
              )}

              {/* Action icons on hover or active */}
              {isActive && !isEditing && (
                <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 ml-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDuplicateSheet(s.id);
                    }}
                    className="p-0.5 hover:text-emerald-600 rounded"
                    title="Duplicate Sheet"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                  {sheets.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteSheet(s.id);
                      }}
                      className="p-0.5 hover:text-red-600 rounded"
                      title="Delete Sheet"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Add Sheet Button */}
        <button
          onClick={onAddSheet}
          className="p-1.5 hover:bg-slate-700 text-slate-400 hover:text-white rounded-md transition-colors"
          title="Add New Sheet"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="text-[10px] text-slate-400 font-mono hidden md:block px-2">
        Double click tab to rename
      </div>
    </div>
  );
};
