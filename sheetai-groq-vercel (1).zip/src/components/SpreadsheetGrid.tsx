import React, { useState, useEffect, useRef } from 'react';
import { SheetData, GridData, CellData, CellStyle } from '../types/spreadsheet';
import { idxToCol, colToIdx, parseCellKey, computeAllCells } from '../utils/formulaEngine';

interface SpreadsheetGridProps {
  sheet: SheetData;
  selectedCellKey: string;
  onSelectCell: (key: string) => void;
  onUpdateCell: (key: string, value: string | number | null, rawInput?: string, style?: CellStyle) => void;
  editingCellKey: string | null;
  setEditingCellKey: (key: string | null) => void;
}

export const SpreadsheetGrid: React.FC<SpreadsheetGridProps> = ({
  sheet,
  selectedCellKey,
  onSelectCell,
  onUpdateCell,
  editingCellKey,
  setEditingCellKey,
}) => {
  const [computedGrid, setComputedGrid] = useState<GridData>({});
  const [editValue, setEditValue] = useState<string>('');
  const [selectionRange, setSelectionRange] = useState<string[]>([]);
  const gridContainerRef = useRef<HTMLDivElement>(null);

  // Compute cell dynamic formulas whenever sheet.cells change
  useEffect(() => {
    const updated = computeAllCells(sheet.cells || {});
    setComputedGrid(updated);
  }, [sheet.cells]);

  // Keep selection range synchronized
  useEffect(() => {
    if (selectedCellKey) {
      setSelectionRange([selectedCellKey]);
    }
  }, [selectedCellKey]);

  // Handle cell click
  const handleCellClick = (key: string) => {
    if (editingCellKey && editingCellKey !== key) {
      handleSaveEdit(editingCellKey);
    }
    onSelectCell(key);
    setSelectionRange([key]);
  };

  // Handle double click to edit
  const handleCellDoubleClick = (key: string) => {
    const cell = computedGrid[key];
    const raw = cell?.rawInput !== undefined ? String(cell.rawInput) : cell?.value !== null ? String(cell?.value ?? '') : '';
    setEditValue(raw);
    setEditingCellKey(key);
  };

  // Save edit value
  const handleSaveEdit = (key: string) => {
    const currentCell = computedGrid[key];
    let newRaw = editValue.trim();
    let val: string | number | null = newRaw;

    if (newRaw.startsWith('=')) {
      val = null; // Will be calculated by formulaEngine
    } else if (newRaw !== '' && !isNaN(Number(newRaw))) {
      val = Number(newRaw);
    } else if (newRaw === '') {
      val = null;
    }

    onUpdateCell(key, val, newRaw, currentCell?.style);
    setEditingCellKey(null);
  };

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (editingCellKey) {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSaveEdit(editingCellKey);
        // Move selection down
        const parsed = parseCellKey(editingCellKey);
        if (parsed) {
          const nextKey = `${parsed.col}${parsed.row + 1}`;
          onSelectCell(nextKey);
        }
      } else if (e.key === 'Escape') {
        setEditingCellKey(null);
      }
      return;
    }

    if (!selectedCellKey) return;

    const parsed = parseCellKey(selectedCellKey);
    if (!parsed) return;

    let targetColIdx = parsed.colIdx;
    let targetRow = parsed.row;

    if (e.key === 'ArrowUp' && targetRow > 1) {
      e.preventDefault();
      targetRow--;
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      targetRow++;
    } else if (e.key === 'ArrowLeft' && targetColIdx > 0) {
      e.preventDefault();
      targetColIdx--;
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      targetColIdx++;
    } else if (e.key === 'Enter') {
      e.preventDefault();
      handleCellDoubleClick(selectedCellKey);
      return;
    } else if (e.key === 'Delete' || e.key === 'Backspace') {
      e.preventDefault();
      onUpdateCell(selectedCellKey, null, '', computedGrid[selectedCellKey]?.style);
      return;
    } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
      // Start typing directly into cell
      setEditValue(e.key);
      setEditingCellKey(selectedCellKey);
      return;
    }

    const nextKey = `${idxToCol(targetColIdx)}${targetRow}`;
    onSelectCell(nextKey);
  };

  // Cell Value Formatter for rendering
  const formatCellValue = (cell: CellData | undefined) => {
    if (!cell) return '';
    const val = cell.computedValue !== undefined ? cell.computedValue : cell.value;
    if (val === null || val === undefined || val === '') return '';

    if (cell.rawInput?.startsWith('=') && typeof val === 'string' && val.startsWith('#')) {
      return val; // Display error codes like #ERROR! or #CIRCULAR!
    }

    const style = cell.style;

    if (style?.format === 'currency' && typeof val === 'number') {
      const symbol = style.currencySymbol || '$';
      return `${symbol}${val.toLocaleString(undefined, {
        minimumFractionDigits: style.decimalPlaces ?? 2,
        maximumFractionDigits: style.decimalPlaces ?? 2,
      })}`;
    }

    if (style?.format === 'percentage' && typeof val === 'number') {
      const pct = val <= 1 && val >= -1 ? val * 100 : val;
      return `${pct.toFixed(1)}%`;
    }

    if (style?.format === 'number' && typeof val === 'number') {
      return val.toLocaleString(undefined, {
        maximumFractionDigits: style.decimalPlaces ?? 2,
      });
    }

    return String(val);
  };

  // Status Bar Statistics for selected range
  const calculateSelectionStats = () => {
    let count = 0;
    let sum = 0;
    let numCount = 0;

    for (const k of selectionRange) {
      const cell = computedGrid[k];
      const val = cell?.computedValue ?? cell?.value;
      if (val !== null && val !== undefined && val !== '') {
        count++;
        if (typeof val === 'number' && !isNaN(val)) {
          sum += val;
          numCount++;
        }
      }
    }

    return {
      count,
      sum: numCount > 0 ? sum : null,
      average: numCount > 0 ? sum / numCount : null,
    };
  };

  const stats = calculateSelectionStats();

  const totalRows = Math.max(sheet.rowCount || 30, 25);
  const totalCols = Math.max(sheet.colCount || 12, 10);

  return (
    <div
      className="flex-1 flex flex-col bg-slate-200 outline-none select-none overflow-hidden"
      tabIndex={0}
      onKeyDown={handleKeyDown}
      ref={gridContainerRef}
    >
      {/* Scrollable Table Canvas */}
      <div className="flex-1 overflow-auto relative">
        <table className="border-collapse bg-white table-fixed w-max text-xs font-sans">
          <thead>
            <tr className="bg-slate-100 text-slate-600 font-semibold sticky top-0 z-20 shadow-sm">
              {/* Top-Left Corner Header */}
              <th className="w-12 h-7 bg-slate-200 border border-slate-300 sticky left-0 z-30 text-center font-mono text-[10px] text-slate-500">
                #
              </th>
              {/* Column Headers A, B, C... */}
              {Array.from({ length: totalCols }).map((_, cIdx) => {
                const colName = idxToCol(cIdx);
                const isSelectedCol = selectedCellKey.startsWith(colName);
                return (
                  <th
                    key={colName}
                    className={`h-7 border border-slate-300 px-2 font-mono text-xs text-center min-w-[90px] max-w-[220px] transition-colors select-none ${
                      isSelectedCol ? 'bg-emerald-200 text-emerald-900 font-bold' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {colName}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: totalRows }).map((_, rIdx) => {
              const rowNum = rIdx + 1;
              const isSelectedRow = selectedCellKey.endsWith(String(rowNum));

              return (
                <tr key={rowNum} className="hover:bg-slate-50/50">
                  {/* Row Header 1, 2, 3... */}
                  <td
                    className={`w-12 h-7 border border-slate-300 font-mono text-[11px] text-center sticky left-0 z-10 transition-colors select-none ${
                      isSelectedRow ? 'bg-emerald-200 text-emerald-900 font-bold' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {rowNum}
                  </td>

                  {/* Grid Cells */}
                  {Array.from({ length: totalCols }).map((_, cIdx) => {
                    const cellKey = `${idxToCol(cIdx)}${rowNum}`;
                    const cellData = computedGrid[cellKey];
                    const isSelected = selectedCellKey === cellKey;
                    const isEditing = editingCellKey === cellKey;
                    const style = cellData?.style || {};

                    const alignClass =
                      style.textAlign === 'center'
                        ? 'text-center'
                        : style.textAlign === 'right'
                        ? 'text-right'
                        : typeof cellData?.computedValue === 'number'
                        ? 'text-right'
                        : 'text-left';

                    return (
                      <td
                        key={cellKey}
                        onClick={() => handleCellClick(cellKey)}
                        onDoubleClick={() => handleCellDoubleClick(cellKey)}
                        style={{
                          backgroundColor: style.backgroundColor || (isSelected ? '#e0f2fe' : 'transparent'),
                          color: style.textColor || '#0f172a',
                        }}
                        className={`h-7 border border-slate-200 px-2 relative font-sans whitespace-nowrap overflow-hidden text-ellipsis cursor-cell transition-all ${alignClass} ${
                          isSelected
                            ? 'ring-2 ring-emerald-500 ring-inset z-10 font-medium'
                            : 'hover:border-slate-400'
                        }`}
                      >
                        {isEditing ? (
                          <input
                            type="text"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            onBlur={() => handleSaveEdit(cellKey)}
                            autoFocus
                            className="absolute inset-0 w-full h-full px-2 bg-white text-slate-900 border-2 border-emerald-500 font-mono text-xs focus:outline-none z-30"
                          />
                        ) : (
                          <span
                            className={`${style.bold ? 'font-bold' : ''} ${style.italic ? 'italic' : ''} ${
                              style.underline ? 'underline' : ''
                            }`}
                          >
                            {formatCellValue(cellData)}
                          </span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Grid Footer Status Bar */}
      <div className="bg-slate-100 border-t border-slate-300 px-3 py-1 flex items-center justify-between text-[11px] text-slate-600 font-mono select-none">
        <div className="flex items-center gap-3">
          <span className="text-slate-500">
            Selected: <strong className="text-slate-800">{selectedCellKey || 'None'}</strong>
          </span>
          {cellFormulaDisplay(computedGrid[selectedCellKey])}
        </div>

        <div className="flex items-center gap-4 text-slate-700">
          <span>Count: <strong>{stats.count}</strong></span>
          {stats.sum !== null && (
            <span>Sum: <strong className="text-emerald-700">{stats.sum.toLocaleString()}</strong></span>
          )}
          {stats.average !== null && (
            <span>Avg: <strong>{stats.average.toFixed(2)}</strong></span>
          )}
        </div>
      </div>
    </div>
  );
};

function cellFormulaDisplay(cell: CellData | undefined) {
  if (!cell || !cell.rawInput || !cell.rawInput.startsWith('=')) return null;
  return (
    <span className="bg-indigo-50 border border-indigo-200 text-indigo-700 px-2 py-0.5 rounded text-[10px]">
      Formula: {cell.rawInput}
    </span>
  );
}
