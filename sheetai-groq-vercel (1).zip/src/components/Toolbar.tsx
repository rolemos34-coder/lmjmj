import React from 'react';
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  DollarSign,
  Percent,
  Hash,
  Sparkles,
  Plus,
  Trash2,
  Wand2,
  PaintBucket,
  Type,
  Baseline,
  Eraser,
} from 'lucide-react';
import { CellStyle } from '../types/spreadsheet';

interface ToolbarProps {
  currentStyle: CellStyle;
  onUpdateStyle: (stylePatch: Partial<CellStyle>) => void;
  onInsertRow: (position: 'above' | 'below') => void;
  onDeleteRow: () => void;
  onInsertColumn: (position: 'left' | 'right') => void;
  onDeleteColumn: () => void;
  onOpenAIFormula: () => void;
  onOpenAIEditSheet: () => void;
  onClearSheet: () => void;
  language?: string;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  currentStyle,
  onUpdateStyle,
  onInsertRow,
  onDeleteRow,
  onInsertColumn,
  onDeleteColumn,
  onOpenAIFormula,
  onOpenAIEditSheet,
  onClearSheet,
  language = 'Portuguese',
}) => {
  return (
    <div className="bg-slate-100 border-b border-slate-300 px-3 py-1.5 flex flex-wrap items-center justify-between gap-2 text-slate-700 shadow-inner">
      {/* Group 1: Formatting Actions */}
      <div className="flex items-center flex-wrap gap-1">
        {/* Bold */}
        <button
          onClick={() => onUpdateStyle({ bold: !currentStyle.bold })}
          className={`p-1.5 rounded hover:bg-slate-200 transition-colors ${
            currentStyle.bold ? 'bg-slate-300 text-slate-900' : 'text-slate-600'
          }`}
          title="Bold (Ctrl+B)"
        >
          <Bold className="w-4 h-4" />
        </button>

        {/* Italic */}
        <button
          onClick={() => onUpdateStyle({ italic: !currentStyle.italic })}
          className={`p-1.5 rounded hover:bg-slate-200 transition-colors ${
            currentStyle.italic ? 'bg-slate-300 text-slate-900' : 'text-slate-600'
          }`}
          title="Italic (Ctrl+I)"
        >
          <Italic className="w-4 h-4" />
        </button>

        {/* Underline */}
        <button
          onClick={() => onUpdateStyle({ underline: !currentStyle.underline })}
          className={`p-1.5 rounded hover:bg-slate-200 transition-colors ${
            currentStyle.underline ? 'bg-slate-300 text-slate-900' : 'text-slate-600'
          }`}
          title="Underline (Ctrl+U)"
        >
          <Underline className="w-4 h-4" />
        </button>

        <div className="h-4 w-[1px] bg-slate-300 mx-1" />

        {/* Text Alignments */}
        <button
          onClick={() => onUpdateStyle({ textAlign: 'left' })}
          className={`p-1.5 rounded hover:bg-slate-200 transition-colors ${
            currentStyle.textAlign === 'left' ? 'bg-slate-300 text-slate-900' : 'text-slate-600'
          }`}
          title="Align Left"
        >
          <AlignLeft className="w-4 h-4" />
        </button>
        <button
          onClick={() => onUpdateStyle({ textAlign: 'center' })}
          className={`p-1.5 rounded hover:bg-slate-200 transition-colors ${
            currentStyle.textAlign === 'center' ? 'bg-slate-300 text-slate-900' : 'text-slate-600'
          }`}
          title="Align Center"
        >
          <AlignCenter className="w-4 h-4" />
        </button>
        <button
          onClick={() => onUpdateStyle({ textAlign: 'right' })}
          className={`p-1.5 rounded hover:bg-slate-200 transition-colors ${
            currentStyle.textAlign === 'right' ? 'bg-slate-300 text-slate-900' : 'text-slate-600'
          }`}
          title="Align Right"
        >
          <AlignRight className="w-4 h-4" />
        </button>

        <div className="h-4 w-[1px] bg-slate-300 mx-1" />

        {/* Text Color Picker */}
        <label
          className="p-1.5 rounded hover:bg-slate-200 transition-colors cursor-pointer flex items-center gap-1 text-xs"
          title="Text Color"
        >
          <Baseline className="w-4 h-4 text-slate-700" />
          <input
            type="color"
            value={currentStyle.textColor || '#000000'}
            onChange={(e) => onUpdateStyle({ textColor: e.target.value })}
            className="w-4 h-4 cursor-pointer opacity-0 absolute"
          />
          <div
            className="w-3 h-3 rounded-full border border-slate-400"
            style={{ backgroundColor: currentStyle.textColor || '#000000' }}
          />
        </label>

        {/* Background Fill Color Picker */}
        <label
          className="p-1.5 rounded hover:bg-slate-200 transition-colors cursor-pointer flex items-center gap-1 text-xs"
          title="Fill Cell Background"
        >
          <PaintBucket className="w-4 h-4 text-slate-700" />
          <input
            type="color"
            value={currentStyle.backgroundColor || '#ffffff'}
            onChange={(e) => onUpdateStyle({ backgroundColor: e.target.value })}
            className="w-4 h-4 cursor-pointer opacity-0 absolute"
          />
          <div
            className="w-3 h-3 rounded-full border border-slate-400"
            style={{ backgroundColor: currentStyle.backgroundColor || '#ffffff' }}
          />
        </label>

        <div className="h-4 w-[1px] bg-slate-300 mx-1" />

        {/* Number Formats */}
        <button
          onClick={() => onUpdateStyle({ format: 'currency', currencySymbol: '$' })}
          className={`p-1.5 rounded hover:bg-slate-200 text-xs font-semibold flex items-center gap-0.5 ${
            currentStyle.format === 'currency' ? 'bg-emerald-200 text-emerald-900' : 'text-slate-700'
          }`}
          title="Format as Currency ($)"
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>Format</span>
        </button>

        <button
          onClick={() => onUpdateStyle({ format: 'percentage' })}
          className={`p-1.5 rounded hover:bg-slate-200 text-xs font-semibold flex items-center gap-0.5 ${
            currentStyle.format === 'percentage' ? 'bg-emerald-200 text-emerald-900' : 'text-slate-700'
          }`}
          title="Format as Percentage (%)"
        >
          <Percent className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => onUpdateStyle({ format: 'number' })}
          className={`p-1.5 rounded hover:bg-slate-200 text-xs font-semibold flex items-center gap-0.5 ${
            currentStyle.format === 'number' ? 'bg-emerald-200 text-emerald-900' : 'text-slate-700'
          }`}
          title="Format as Plain Number"
        >
          <Hash className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => onUpdateStyle({ format: 'text' })}
          className={`p-1.5 rounded hover:bg-slate-200 text-xs font-semibold flex items-center gap-0.5 ${
            currentStyle.format === 'text' ? 'bg-emerald-200 text-emerald-900' : 'text-slate-700'
          }`}
          title="Format as Plain Text"
        >
          <Type className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Group 2: Grid Rows / Cols + AI Utilities */}
      <div className="flex items-center flex-wrap gap-1.5">
        {/* Row/Col Operations */}
        <div className="flex items-center gap-1 bg-slate-200 p-0.5 rounded text-xs">
          <button
            onClick={() => onInsertRow('below')}
            className="px-2 py-1 hover:bg-slate-300 rounded text-slate-700 flex items-center gap-1"
            title="Insert Row Below"
          >
            <Plus className="w-3 h-3" /> Row
          </button>
          <button
            onClick={() => onDeleteRow()}
            className="px-2 py-1 hover:bg-red-200 rounded text-red-700 flex items-center gap-1"
            title="Delete Selected Row"
          >
            <Trash2 className="w-3 h-3" /> Row
          </button>
          <div className="h-3 w-[1px] bg-slate-300" />
          <button
            onClick={() => onInsertColumn('right')}
            className="px-2 py-1 hover:bg-slate-300 rounded text-slate-700 flex items-center gap-1"
            title="Insert Column Right"
          >
            <Plus className="w-3 h-3" /> Col
          </button>
          <button
            onClick={() => onDeleteColumn()}
            className="px-2 py-1 hover:bg-red-200 rounded text-red-700 flex items-center gap-1"
            title="Delete Selected Column"
          >
            <Trash2 className="w-3 h-3" /> Col
          </button>
        </div>

        {/* Clear Sheet Button */}
        <button
          onClick={onClearSheet}
          className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs px-2.5 py-1.5 rounded font-medium transition-colors"
          title={language === 'Portuguese' ? 'Limpar todas as células da aba ativa' : 'Clear all cells in active sheet'}
        >
          <Eraser className="w-3.5 h-3.5 text-rose-600" />
          <span>{language === 'Portuguese' ? 'Limpar Planilha' : 'Clear Sheet'}</span>
        </button>

        {/* AI Formula Generator Button */}
        <button
          onClick={onOpenAIFormula}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs px-2.5 py-1.5 rounded font-medium shadow-sm transition-colors"
          title="Ask AI to write a formula for the active cell"
        >
          <Wand2 className="w-3.5 h-3.5" />
          <span>AI Formula</span>
        </button>

        {/* AI Transform Sheet Button */}
        <button
          onClick={onOpenAIEditSheet}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-900 text-slate-100 text-xs px-2.5 py-1.5 rounded font-medium transition-colors border border-slate-700"
          title="Prompt AI to edit, calculate, or format this sheet"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>AI Modify Sheet</span>
        </button>
      </div>
    </div>
  );
};
