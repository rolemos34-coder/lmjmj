import { TemplatePreset } from '../types/spreadsheet';

export const STARTER_TEMPLATES: TemplatePreset[] = [
  {
    id: 'saas-financial-model',
    title: 'Modelo Financeiro SaaS 12 Meses',
    category: 'Finanças e Contabilidade',
    description: 'Acompanhe MRR, Churn, LTV, CAC, OpEx, Margem Bruta e Projeção de Lucro Líquido com fórmulas integradas.',
    prompt: 'Crie uma Projeção Financeira detalhada de 12 meses para uma startup SaaS B2B em Português do Brasil. Inclua linhas para MRR Inicial, Novo MRR, MRR Expansão, Churn MRR, MRR Final, CAC, LTV, Custos dos Produtos (COGS), Salários, Marketing, Servidores AWS, Margem Bruta % e Lucro Líquido com fórmulas SOMA, MÉDIA e % em moeda R$.',
    iconName: 'TrendingUp',
  },
  {
    id: 'personal-budget',
    title: 'Orçamento Pessoal e Rastreador de Economias',
    category: 'Finanças Pessoais',
    description: 'Fontes de renda mensal, despesas fixas, despesas variáveis, metas de economia e saldo patrimonial.',
    prompt: 'Crie um Planejador de Orçamento Pessoal mensal em Português do Brasil. Inclua seções para Receitas (Salário, Freelance, Investimentos), Despesas Fixas (Aluguel, Contas, Seguro), Despesas Variáveis (Supermercado, Lazer, Restaurantes), Investimentos, e um resumo calculando Receita Total, Despesas Totais, Economia Líquida e Taxa de Poupança % com formatação em R$.',
    iconName: 'Wallet',
  },
  {
    id: 'project-gantt-tracker',
    title: 'Cronograma de Projeto e Controle Gantt',
    category: 'Gestão de Projetos',
    description: 'Divisão de tarefas, responsáveis, status, datas de início, duração, dependências e % de conclusão.',
    prompt: 'Crie uma planilha de Cronograma e Matriz de Projeto em Português do Brasil. Colunas: ID Tarefa, Nome da Tarefa, Responsável, Categoria, Data Início, Data Fim, Duração (Dias), Status (Não Iniciado, Em Andamento, Concluído), Conclusão %, e Horas Estimadas vs Reais.',
    iconName: 'Kanban',
  },
  {
    id: 'sales-pipeline',
    title: 'Funil de Vendas e Valoração de Leads',
    category: 'Marketing e Vendas',
    description: 'Pontuação de leads, estágio do funil, valor do contrato, previsão ponderada, probabilidade e desempenho.',
    prompt: 'Crie uma planilha de Funil de Vendas Comercial em Português do Brasil. Inclua Nome do Lead, Empresa, Origem, Estágio (Prospecção, Demonstração, Proposta, Fechado Ganho, Fechado Perdido), Probabilidade %, Valor do Negócio (R$), Previsão Ponderada (R$), Responsável, e Data Prevista de Fechamento com fórmulas de totalização.',
    iconName: 'Target',
  },
  {
    id: 'inventory-management',
    title: 'Controle de Estoque e Ponto de Reposição',
    category: 'RH e Operações',
    description: 'Rastreamento de SKU, custo unitário, nível de estoque, alerta de reposição e avaliação total.',
    prompt: 'Crie uma planilha de Controle e Avaliação de Estoque em Português do Brasil. Colunas: SKU, Descrição do Item, Categoria, Local no Almoxarifado, Custo Unitário (R$), Preço de Venda (R$), Quantidade em Estoque, Ponto de Reposição, Alerta (OK / REPOUSAR), Valor Total em Estoque (R$), e Margem %.',
    iconName: 'Package',
  },
  {
    id: 'ecommerce-roi-calculator',
    title: 'Calculadora de ROI e Gastos com Anúncios E-commerce',
    category: 'Marketing e Vendas',
    description: 'Desempenho de canais de anúncios, ROAS, CPA, taxas de conversão e análise de margem de lucro.',
    prompt: 'Crie um Dashboard de Desempenho de Marketing E-commerce em Português do Brasil. Inclua Canais (Meta Ads, Google Search, TikTok Ads, E-mail Marketing), Investimento em Anúncios, Impressões, Cliques, Conversões, Receita Gerada, ROAS (Receita / Investimento), CPA (Investimento / Conversões) e Retorno Líquido com fórmulas.',
    iconName: 'ShoppingBag',
  },
];

