export type CellFormatType = 'text' | 'number' | 'currency' | 'percentage' | 'date';

export interface CellStyle {
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  textColor?: string;
  backgroundColor?: string;
  textAlign?: 'left' | 'center' | 'right';
  format?: CellFormatType;
  currencySymbol?: string;
  decimalPlaces?: number;
}

export interface CellData {
  value: string | number | boolean | null;
  rawInput?: string; // e.g. "=SUM(B2:B10)"
  computedValue?: string | number | boolean | null;
  style?: CellStyle;
  comment?: string;
}

export type GridData = {
  [cellKey: string]: CellData; // e.g. "A1", "B2"
};

export interface ColumnWidths {
  [colIndex: number]: number;
}

export interface ChartConfig {
  id: string;
  type: 'bar' | 'line' | 'pie' | 'area';
  title: string;
  dataRange: {
    startCell: string;
    endCell: string;
  };
  xAxisColumn: string; // e.g. "A"
  dataColumns: string[]; // e.g. ["B", "C"]
}

export interface SheetData {
  id: string;
  name: string;
  cells: GridData;
  rowCount: number;
  colCount: number;
  columnWidths?: ColumnWidths;
  charts?: ChartConfig[];
}

export interface SpreadsheetWorkbook {
  id: string;
  title: string;
  description?: string;
  sheets: SheetData[];
  activeSheetId: string;
  createdPrompt?: string;
  language?: string;
  insights?: {
    summary: string;
    keyMetrics: { label: string; value: string; trend?: 'up' | 'down' | 'neutral' }[];
    recommendations: string[];
    formulasUsed: { formula: string; purpose: string }[];
  };
}

export interface TemplatePreset {
  id: string;
  title: string;
  category: string;
  description: string;
  prompt: string;
  iconName: string;
}
