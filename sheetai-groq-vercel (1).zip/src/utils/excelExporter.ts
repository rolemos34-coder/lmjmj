import * as XLSX from 'xlsx';
import { SheetData, SpreadsheetWorkbook, GridData, CellData } from '../types/spreadsheet';
import { parseCellKey, idxToCol, colToIdx } from './formulaEngine';

export function exportWorkbookToExcel(workbook: SpreadsheetWorkbook, fileName?: string) {
  const wb = XLSX.utils.book_new();

  for (const sheet of workbook.sheets) {
    // Determine max dimensions
    let maxRow = sheet.rowCount || 20;
    let maxColIdx = sheet.colCount || 10;

    Object.keys(sheet.cells).forEach((key) => {
      const parsed = parseCellKey(key);
      if (parsed) {
        if (parsed.row > maxRow) maxRow = parsed.row;
        if (parsed.colIdx > maxColIdx) maxColIdx = parsed.colIdx;
      }
    });

    // Create 2D matrix
    const dataMatrix: (string | number | boolean | null)[][] = [];
    for (let r = 0; r < maxRow; r++) {
      const rowArr: (string | number | boolean | null)[] = [];
      for (let c = 0; c <= maxColIdx; c++) {
        const key = `${idxToCol(c)}${r + 1}`;
        const cell = sheet.cells[key];
        if (!cell) {
          rowArr.push(null);
        } else {
          rowArr.push(cell.computedValue ?? cell.value ?? null);
        }
      }
      dataMatrix.push(rowArr);
    }

    const ws = XLSX.utils.aoa_to_sheet(dataMatrix);
    XLSX.utils.book_append_sheet(wb, ws, sheet.name.replace(/[*?:/\\\[\]]/g, '') || 'Sheet');
  }

  const name = (fileName || workbook.title || 'Spreadsheet').replace(/[^a-z0-9_-]/gi, '_');
  XLSX.writeFile(wb, `${name}.xlsx`);
}

export function exportSheetToCSV(sheet: SheetData, sheetName?: string) {
  let maxRow = sheet.rowCount || 20;
  let maxColIdx = sheet.colCount || 10;

  Object.keys(sheet.cells).forEach((key) => {
    const parsed = parseCellKey(key);
    if (parsed) {
      if (parsed.row > maxRow) maxRow = parsed.row;
      if (parsed.colIdx > maxColIdx) maxColIdx = parsed.colIdx;
    }
  });

  const dataMatrix: (string | number | boolean | null)[][] = [];
  for (let r = 0; r < maxRow; r++) {
    const rowArr: (string | number | boolean | null)[] = [];
    for (let c = 0; c <= maxColIdx; c++) {
      const key = `${idxToCol(c)}${r + 1}`;
      const cell = sheet.cells[key];
      rowArr.push(cell ? (cell.computedValue ?? cell.value ?? null) : null);
    }
    dataMatrix.push(rowArr);
  }

  const ws = XLSX.utils.aoa_to_sheet(dataMatrix);
  const csv = XLSX.utils.sheet_to_csv(ws);

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${(sheetName || sheet.name || 'Sheet').replace(/[^a-z0-9_-]/gi, '_')}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export async function parseExcelOrCSVFile(file: File): Promise<SpreadsheetWorkbook> {
  const data = await file.arrayBuffer();
  const wb = XLSX.read(data, { type: 'array' });

  const sheets: SheetData[] = [];

  for (let i = 0; i < wb.SheetNames.length; i++) {
    const sheetName = wb.SheetNames[i];
    const ws = wb.Sheets[sheetName];
    const jsonMatrix = XLSX.utils.sheet_to_json<(string | number | boolean)[]>(ws, { header: 1 });

    const cells: GridData = {};
    let rowCount = Math.max(jsonMatrix.length, 25);
    let colCount = 10;

    for (let r = 0; r < jsonMatrix.length; r++) {
      const row = jsonMatrix[r] || [];
      if (row.length > colCount) colCount = row.length;

      for (let c = 0; c < row.length; c++) {
        const val = row[c];
        if (val !== undefined && val !== null && val !== '') {
          const key = `${idxToCol(c)}${r + 1}`;
          const isNum = typeof val === 'number';
          
          cells[key] = {
            value: val,
            computedValue: val,
            rawInput: String(val),
            style: {
              bold: r === 0, // Assume row 0 header
              format: isNum ? 'number' : 'text',
            },
          };
        }
      }
    }

    sheets.push({
      id: `sheet-${Date.now()}-${i}`,
      name: sheetName,
      cells,
      rowCount: Math.max(rowCount, 30),
      colCount: Math.max(colCount, 12),
    });
  }

  return {
    id: `wb-${Date.now()}`,
    title: file.name.replace(/\.[^/.]+$/, ''),
    sheets,
    activeSheetId: sheets[0]?.id || 'sheet-0',
  };
}
