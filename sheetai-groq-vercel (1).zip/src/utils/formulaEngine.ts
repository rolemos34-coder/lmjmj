import { GridData } from '../types/spreadsheet';

// Convert column letter to 0-based index: A -> 0, B -> 1, AA -> 26
export function colToIdx(col: string): number {
  let idx = 0;
  const uppercaseCol = col.toUpperCase();
  for (let i = 0; i < uppercaseCol.length; i++) {
    idx = idx * 26 + uppercaseCol.charCodeAt(i) - 64;
  }
  return idx - 1;
}

// Convert 0-based index to column letter: 0 -> A, 1 -> B, 26 -> AA
export function idxToCol(idx: number): string {
  let col = '';
  let tempIdx = idx + 1;
  while (tempIdx > 0) {
    const rem = (tempIdx - 1) % 26;
    col = String.fromCharCode(65 + rem) + col;
    tempIdx = Math.floor((tempIdx - 1) / 26);
  }
  return col;
}

// Parse cell key "B4" into { col: "B", row: 4, colIdx: 1, rowIdx: 3 }
export function parseCellKey(key: string): { col: string; row: number; colIdx: number; rowIdx: number } | null {
  const match = key.match(/^([A-Z]+)(\d+)$/i);
  if (!match) return null;
  const col = match[1].toUpperCase();
  const row = parseInt(match[2], 10);
  return {
    col,
    row,
    colIdx: colToIdx(col),
    rowIdx: row - 1,
  };
}

// Expand a range like "A1:B3" into ["A1", "A2", "A3", "B1", "B2", "B3"]
export function expandRange(rangeStr: string): string[] {
  const parts = rangeStr.split(':');
  if (parts.length === 1) return [parts[0].toUpperCase().trim()];
  if (parts.length !== 2) return [];

  const start = parseCellKey(parts[0].trim());
  const end = parseCellKey(parts[1].trim());
  if (!start || !end) return [];

  const minColIdx = Math.min(start.colIdx, end.colIdx);
  const maxColIdx = Math.max(start.colIdx, end.colIdx);
  const minRow = Math.min(start.row, end.row);
  const maxRow = Math.max(start.row, end.row);

  const keys: string[] = [];
  for (let c = minColIdx; c <= maxColIdx; c++) {
    const colLetter = idxToCol(c);
    for (let r = minRow; r <= maxRow; r++) {
      keys.push(`${colLetter}${r}`);
    }
  }
  return keys;
}

// Helper to extract numeric values from a cell or range
function getValuesFromRangeOrCell(
  arg: string,
  grid: GridData,
  visited: Set<string>
): number[] {
  arg = arg.trim();
  if (arg.includes(':')) {
    const keys = expandRange(arg);
    const nums: number[] = [];
    for (const k of keys) {
      const val = evaluateCell(k, grid, new Set(visited));
      if (typeof val === 'number' && !isNaN(val)) {
        nums.push(val);
      } else if (typeof val === 'string' && val !== '' && !isNaN(Number(val))) {
        nums.push(Number(val));
      }
    }
    return nums;
  }

  // Single cell or constant
  if (/^[A-Z]+\d+$/i.test(arg)) {
    const val = evaluateCell(arg.toUpperCase(), grid, new Set(visited));
    if (typeof val === 'number' && !isNaN(val)) return [val];
    if (typeof val === 'string' && val !== '' && !isNaN(Number(val))) return [Number(val)];
    return [];
  }

  const parsedNum = Number(arg);
  if (!isNaN(parsedNum)) return [parsedNum];
  return [];
}

// Recursive formula evaluator
export function evaluateCell(
  cellKey: string,
  grid: GridData,
  visited: Set<string> = new Set()
): string | number | boolean | null {
  const cell = grid[cellKey];
  if (!cell) return null;

  const raw = cell.rawInput !== undefined ? String(cell.rawInput) : cell.value !== null ? String(cell.value) : '';
  if (!raw.startsWith('=')) {
    // If not formula, return literal value
    if (cell.value === null || cell.value === undefined) return '';
    return cell.value;
  }

  // Check circular reference
  if (visited.has(cellKey)) {
    return '#CIRCULAR!';
  }
  visited.add(cellKey);

  const expr = raw.substring(1).trim();
  try {
    return parseAndEvalExpr(expr, grid, visited);
  } catch (err) {
    return '#ERROR!';
  }
}

function parseAndEvalExpr(
  expr: string,
  grid: GridData,
  visited: Set<string>
): string | number | boolean | null {
  expr = expr.trim();
  if (!expr) return '';

  // 1. Check Function Calls (SUM, AVERAGE, COUNT, MIN, MAX, IF, ROUND, CONCAT, PRODUCT, VLOOKUP)
  const funcMatch = expr.match(/^([A-Z_]+)\((.*)\)$/i);
  if (funcMatch) {
    const funcName = funcMatch[1].toUpperCase();
    const argsStr = funcMatch[2];
    const args = splitTopLevelArgs(argsStr);

    switch (funcName) {
      case 'SUM': {
        let total = 0;
        for (const arg of args) {
          const vals = getValuesFromRangeOrCell(arg, grid, visited);
          total += vals.reduce((a, b) => a + b, 0);
        }
        return total;
      }

      case 'AVERAGE':
      case 'AVG': {
        let total = 0;
        let count = 0;
        for (const arg of args) {
          const vals = getValuesFromRangeOrCell(arg, grid, visited);
          total += vals.reduce((a, b) => a + b, 0);
          count += vals.length;
        }
        return count > 0 ? total / count : 0;
      }

      case 'COUNT': {
        let count = 0;
        for (const arg of args) {
          const vals = getValuesFromRangeOrCell(arg, grid, visited);
          count += vals.length;
        }
        return count;
      }

      case 'MIN': {
        let minVal: number | null = null;
        for (const arg of args) {
          const vals = getValuesFromRangeOrCell(arg, grid, visited);
          for (const v of vals) {
            if (minVal === null || v < minVal) minVal = v;
          }
        }
        return minVal !== null ? minVal : 0;
      }

      case 'MAX': {
        let maxVal: number | null = null;
        for (const arg of args) {
          const vals = getValuesFromRangeOrCell(arg, grid, visited);
          for (const v of vals) {
            if (maxVal === null || v > maxVal) maxVal = v;
          }
        }
        return maxVal !== null ? maxVal : 0;
      }

      case 'PRODUCT':
      case 'MULTIPLY': {
        let prod = 1;
        let count = 0;
        for (const arg of args) {
          const vals = getValuesFromRangeOrCell(arg, grid, visited);
          for (const v of vals) {
            prod *= v;
            count++;
          }
        }
        return count > 0 ? prod : 0;
      }

      case 'ROUND': {
        if (args.length === 0) return 0;
        const val = Number(parseAndEvalExpr(args[0], grid, visited));
        const decimals = args.length > 1 ? Number(parseAndEvalExpr(args[1], grid, visited)) : 0;
        if (isNaN(val)) return '#VALUE!';
        const factor = Math.pow(10, isNaN(decimals) ? 0 : decimals);
        return Math.round(val * factor) / factor;
      }

      case 'IF': {
        if (args.length < 2) return '#ARGS!';
        const condition = parseAndEvalExpr(args[0], grid, visited);
        const isTrue = condition === true || (typeof condition === 'number' && condition !== 0) || (typeof condition === 'string' && condition.toLowerCase() === 'true');
        if (isTrue) {
          return parseAndEvalExpr(args[1], grid, visited);
        } else {
          return args.length > 2 ? parseAndEvalExpr(args[2], grid, visited) : false;
        }
      }

      case 'CONCAT':
      case 'CONCATENATE': {
        let result = '';
        for (const arg of args) {
          if (arg.startsWith('"') && arg.endsWith('"')) {
            result += arg.slice(1, -1);
          } else {
            const evaluated = parseAndEvalExpr(arg, grid, visited);
            result += String(evaluated ?? '');
          }
        }
        return result;
      }

      default:
        // Fall through to basic arithmetic or return name
        break;
    }
  }

  // 2. Simple arithmetic expression substitution for single cell references or math formulas
  // Replace cell references like A1, B12 with their evaluated values
  const replacedExpr = expr.replace(/\b([A-Z]+)(\d+)\b/gi, (match) => {
    const val = evaluateCell(match.toUpperCase(), grid, new Set(visited));
    if (val === null || val === undefined || val === '') return '0';
    if (typeof val === 'number') return String(val);
    if (typeof val === 'boolean') return val ? '1' : '0';
    if (typeof val === 'string' && !isNaN(Number(val))) return val;
    // Quote string if text
    return `"${val.replace(/"/g, '\\"')}"`;
  });

  // Safe evaluation for standard math expressions (like `B2 * 0.15 + C2`)
  try {
    // Only allow math chars, numbers, parentheses, operators, quotes, space
    if (/^[0-9+\-*/%^().,\s"'>=<!&|]*$/.test(replacedExpr)) {
      // replace '^' with '**'
      const jsExpr = replacedExpr.replace(/\^/g, '**');
      // eslint-disable-next-line no-new-func
      const result = new Function(`return (${jsExpr});`)();
      if (typeof result === 'number') {
        if (isNaN(result)) return '#VALUE!';
        if (!isFinite(result)) return '#DIV/0!';
        return Math.round(result * 100000000) / 100000000;
      }
      return result;
    }
  } catch (e) {
    // ignore math eval error and return replaced string or error
  }

  return expr;
}

function splitTopLevelArgs(str: string): string[] {
  const args: string[] = [];
  let current = '';
  let inQuotes = false;
  let parenLevel = 0;

  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    if (char === '"' && str[i - 1] !== '\\') {
      inQuotes = !inQuotes;
      current += char;
    } else if (char === '(' && !inQuotes) {
      parenLevel++;
      current += char;
    } else if (char === ')' && !inQuotes) {
      parenLevel--;
      current += char;
    } else if (char === ',' && !inQuotes && parenLevel === 0) {
      args.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  if (current.trim()) {
    args.push(current.trim());
  }
  return args;
}

// Compute all computedValues in a Grid
export function computeAllCells(grid: GridData): GridData {
  const updatedGrid: GridData = { ...grid };
  for (const key of Object.keys(updatedGrid)) {
    const cell = updatedGrid[key];
    if (cell && cell.rawInput && cell.rawInput.startsWith('=')) {
      const computed = evaluateCell(key, updatedGrid);
      updatedGrid[key] = {
        ...cell,
        computedValue: computed,
        value: computed,
      };
    } else if (cell) {
      updatedGrid[key] = {
        ...cell,
        computedValue: cell.value,
      };
    }
  }
  return updatedGrid;
}
